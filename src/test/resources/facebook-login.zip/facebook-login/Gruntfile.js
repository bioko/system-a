/* Gruntfile.js */

module.exports = function(grunt) {

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    compass: {                 
      dev: {                    
        options: {
            cssDir  : 'app/styles/css',
            sassDir : 'app/styles/sass'
        }
      }
    },
    karma: {
      options: {
        singleRun: true,
        autoWatch: false,
        browsers: ['Chrome']
      },
      unit: {
      	configFile: 'config/karma.conf.js'
      }
    },
    watch: {
      compass: {
        files:[
          'app/styles/sass/*.scss',
        ],
        tasks: ['compass:dev']
      }
    }
  });

  //load tasks libraries
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-compass');
  grunt.loadNpmTasks('grunt-karma');
  
};
