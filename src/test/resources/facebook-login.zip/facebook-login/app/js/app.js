'use strict'

/**
 * facebookSpikeApp
 *
 * @author   : Mikol
 * @copyright: Engaged S.r.l.
 */

 angular.module('engaged.facebookspikeapp', ['engaged.facebookspikecontrollers','engaged.facebook',
 	'xinspector.services', 'commons.config']).
 	run(['$window', function($window) {
 		$window.fbAsincInit();
 	}])