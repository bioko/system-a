'use strict'

angular.module('engaged.auth', []).
	factory ('srvAuth', [function(srvAuth) {
		var container = { logged : false };
		var service = {};

		service.setLogged = function(logged) {
			container.logged = logged;
		}

		service.isLogged = function () {
			return logged;
		}

		service.setToken = function(newToken) {
			container.authToken = newToken;
		}

		service.getToken = function() {
			return container.authToken;
		}

		service.setUser = function(newUser) {
			container.user = newUser;
		}

		service.getUser = function() {
			return container.user;
		}

		service.getContainer = function() {
			return container;
		}

		return service;
	}]);
	