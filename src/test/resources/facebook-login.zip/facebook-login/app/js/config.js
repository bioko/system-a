'use strict';

/**
 * XRest Inspector
 * Configuration 
 *
 * @author   : Mikol , Hal9087
 * @copyright: Engaged S.r.l. Treeweb S.r.l.
 */

angular.module('commons.config',[])

.constant('xconfig', {
	apiEndPoint : 'http://local.engaged.it/engagedServer/api/',
	logLevel  : 0
});