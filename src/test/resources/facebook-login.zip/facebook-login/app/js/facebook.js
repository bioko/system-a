'use strict'

 angular.module('engaged.facebook', ['engaged.auth']).
 	run(['$rootScope', '$window','srvAuth',
 		function ($rootScope, $window, srvAuth) {
 			$window.fbAsincInit = function () {
 				if (typeof FB === "undefined") {
 				 	return;
 				}

 				$rootScope.FB = FB;

 				$rootScope.FB.init({
 					appId: '404844866285999',
 					channelUrl: 'app/channel.html',
 					status: true,
 					cookie: true,
 					xfbml: true
 				});

 				$rootScope.FB.Event.subscribe('auth.authResponseChange', function(response) {
 					if (response.status === 'connected') {
 						srvAuth.setToken(response.authResponse.accessToken);
 						$rootScope.FB.api('/me', function(response) {
 							srvAuth.setUser(response);
 						});
 					}
 				});

 				srvAuth.logout = function() {
 					$rootScope.FB.logout(function(response) {
 						srvAuth.setUser({});
 					});
 				}
 			};

 		}]);