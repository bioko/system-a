angular.module('engaged.facebookspikecontrollers', ['engaged.auth', 'xinspector.services','ui','ui.compat','ui.bootstrap']).

	controller('MainController',['$scope', 'srvAuth','XApiResource','Alert', function($scope, srvAuth, XApiResource, Alert) {

		$scope.app='systemA';
		$scope.ver='1.0';

		$scope.request = {
			name: 'POST_facebook-authenticated',
			urlPath : '',
			queryString : { },
			header : { },
			body : { }
		};

		$scope.userContainer = srvAuth.getContainer();

		$scope.getToken = function() {
			// $http.
		}

		$scope.submitCommand = function() {

			$scope.request.body = JSON.parse(JSON.stringify($scope.userContainer.user));
			$scope.request.body.authToken = $scope.userContainer.authToken;

			XApiResource
			.runMyCommand($scope.app, $scope.ver, $scope.request, $scope.request.urlPath, $scope.request.queryString, $scope.request.header, $scope.request.body)
			.success(function (data, status, headers, config) {
	  			$scope.response = data;
	  			$scope.responseType = headers('Content-Type');
	  			Alert.clear()
	    		.get("commandAlerts")
	    		.success("Well done! Command successfully executed.");
			}).error(function(response,status,headers){
	  			Alert
	    		.clear()
	    		.get("commandAlerts")
				.error(status + ': ' + response[0].errorMessage + ' [Code ' + response[0].errorCode + ']');

				$scope.response = response;
				$scope.responseType = headers('Content-Type');
			});
		}
	}])