'use strict';

/**
 * XRest Inspector
 * Services
 *
 * @author   : Mikol , Hal9087
 * @copyright: Engaged S.r.l. Treeweb S.r.l.
 */

angular.module('xinspector.services', ['commons.config','ngResourcePromise', 'engaged.utils'])

/**
 * XApiResource Rest Service Factory
 * THINK [RB] non credo che l'oggetto $esource possa fare al 
 * caso nostro , forse sarebbe meglio pensare ad dei nostri oggetti/factory di oggetti
 * basati su $http ...
 */

  .factory('XApiResource',['$http', '$resourcePromise', 'xconfig', 'Commons',
                         function($http, $resource , xconfig, Commons){
	
    var apiEndPoint = xconfig.apiEndPoint;
    
    var resource = $resource(apiEndPoint + ':app/:ver/:entity/:id:verb/:entityVerb',{
      id : '@id'	
    },{
      getCommandList : {method :'OPTIONS', params:{verb   :'command-list'}, isArray : true },
      getCommandInfo : {method :'OPTIONS', params:{entity :'command-invocation-info'}, isArray : true }
    });
    
    resource.runMyCommand = function(app, ver, command, urlPath, queryString, headers, requestBody) {
    	if (app && ver && command) {
			var method = resource.getRequestMethod(command.name);
			var entity = resource.getCommandName(command.name);
			
			var url = apiEndPoint + app + '/' + ver + '/' + entity + '/';
			for (var i in urlPath) {
				if (!Commons.isEmptyObject(urlPath[i])) {
					url += urlPath[i];
				}
			}

			return $http({
				method: method,
				url: url,
				data: requestBody,
				params: queryString,
				headers: headers,
			});
    	} else {
			return false;
		}
    };

    //FIXME
    resource.getMyApplications = function() {
      return [ 
		{slug : 'promo', ver : '1.0', name : 'Promo'},
		{slug : 'taxishare', ver : '1.0', name : 'Taxishare'} 
      ];
    };

    resource.getRequestMethod = function(string) {
      if(!angular.isString(string)) 
	return string;
      
      var match = string.match(/^(OPTIONS|GET|POST|PUT|DELETE)/i);
      if(match)
	return match[0];
      else
	return string;
      // [RB] - The 'i' modifier is used to perform case-insensitive matching. 
      // it's right? 
	// [MF] - Back-end should provide names in lower-case, but it's a 
      // nice-to-have.
    };

    resource.getCommandName = function(string) {
      if(!angular.isString(string)) 
	return string;
      
      var method = resource.getRequestMethod(string);
      return string.replace(method + '_', '');
    };
    
    return resource;
  }])


/**
 * Alert - AlertProto factory
 */
.factory('Alert',['AlertProto',function(AlertProto) {
	var instances = [];

	return {
		get : function(key) {
			if(instances[key] === undefined) {
				instances[key] = new AlertProto(key);
			}
			return instances[key];
		},
		clear : function() {
			for(var alertProto in instances){
				instances[alertProto].clear();
			}
			return this;
		}
	};
}])


/**
 * AlertProto 
 */
.factory('AlertProto', ['$rootScope', function($rootScope) {
		
		var Alert = function(key){
			this.key = key;
			$rootScope[this.key] = [];
		};

		Alert.prototype.add = function (type,msg) {
			$rootScope[this.key].push({type : type , msg : msg});
		    return this;
		};

		Alert.prototype.success = function (msg) {
			return this.add('success',msg);
		};

		Alert.prototype.error = function (msg) {
			return this.add('error',msg);
		};

		Alert.prototype.warning = function (msg) {
			return this.add('warning',msg);
		};

		Alert.prototype.info = function (msg) {
			return this.add('info',msg);
		};

		Alert.prototype.clear = function () {
			$rootScope[this.key] = [];
			return this;
		};

		Alert.prototype.delete = function (index) {
			$rootScope[this.key].splice(index, 1);
			return this;
		};

		$rootScope.closeAlert = function(alerts,index) {
			alerts.splice(index);
		};

		return Alert;
}]);
