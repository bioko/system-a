'use strict'

/**
 * Engaged Utilities
 * Utilities
 *
 * @author   : Mikol, hal9086
 * @copyright: Engaged S.r.l., Treeweb S.r.l.
 */

angular.module('engaged.utils', []) 

  .factory('Commons', function() {
    return {
      isEmptyObject: function(obj) {
        // http://stackoverflow.com/questions/4994201/is-object-empty
        if (obj == null) {
          return true;
        }
	
        if (obj.length && obj.length > 0) {
          return false;
        }
	
        if (obj.length === 0) {
          return false;
        }

        for (var key in obj) {
          if (Object.hasOwnProperty.call(obj, key)) {
            return false;
          }
        }
      
        return true;
      },
      findByMatchingProperty: function(set, key, value) {
        var filtered = [ ];
        for (var i in set) {
          if (set[i][key] === value) {
            filtered.push(set[i]);
          }
        }
        return filtered;
      }
    };
  })

  .factory('Base64', [function() {
    return {
      encode: function(input) {
        return window.btoa(unescape(encodeURIComponent(input)));
        // return "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==";
        // return "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==";
      },
      decode: function(data) {
        return "Hi";
      }
    }
  }])

/**
 * Utils to workaround bug in Angularjs
 * @see https://github.com/angular/angular.js/pull/1661
 */
  .factory('WorkaroundLoseFocus', [ 'Commons', function(Commons) {
    return {
      removeValues: function(wrapObj) {
        var obj;
        if (Object.prototype.toString.call(wrapObj) === "[object Array]") {
          obj = [];
        } else {
          obj = {};
        }

        for (var i in wrapObj) {
          if (wrapObj[i].value) {
            obj[i] = wrapObj[i].value;
          } else if (Object.prototype.toString.call(wrapObj[i]) === "[object Object]")  {
            obj[i] = this.removeValues(wrapObj[i]);
          } else if (Object.prototype.toString.call(wrapObj[i]) === "[object Array]") {
            obj[i] = this.removeValues(wrapObj[i]);
          }
        }
        
        return obj;
      },
      insertValues: function(obj, wrapObj) {
        for (var i in obj) {
          wrapObj[i].value = obj[i];
        }
      }
    };
  }])

  .filter('removeValues', ['WorkaroundLoseFocus', function(WorkaroundLoseFocus) {
    return function (input) {
      return WorkaroundLoseFocus.removeValues(input);
    }
  }]);
